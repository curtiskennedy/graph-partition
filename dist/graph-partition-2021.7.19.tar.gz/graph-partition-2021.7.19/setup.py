# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['graph_partition', 'graph_partition.algorithms', 'graph_partition.classes']

package_data = \
{'': ['*'], 'graph_partition': ['test-instances/*']}

install_requires = \
['PyInquirer>=1.0.3,<2.0.0', 'pyfiglet>=0.8.post1,<0.9']

entry_points = \
{'console_scripts': ['partition = graph_partition.main:cli']}

setup_kwargs = {
    'name': 'graph-partition',
    'version': '2021.7.19',
    'description': '',
    'long_description': None,
    'author': 'curtiskennedy',
    'author_email': 'curtisdeankennedy@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

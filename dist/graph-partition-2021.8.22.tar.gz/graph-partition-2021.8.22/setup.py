# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['graph_partition', 'graph_partition.algorithms', 'graph_partition.classes']

package_data = \
{'': ['*']}

install_requires = \
['PyInquirer>=1.0.3,<2.0.0', 'pyfiglet>=0.8.post1,<0.9']

entry_points = \
{'console_scripts': ['partition = graph_partition.main:cli']}

setup_kwargs = {
    'name': 'graph-partition',
    'version': '2021.8.22',
    'description': 'vertex-weighted graph partitioning',
    'long_description': "***************\nGraph-Partition\n***************\n\n| Approx-1: MAX-MIN k=2 on 2-connected graphs\n| Approx-2: MAX-MIN k=2 on connected graphs\n| Approx-3: MIN-MAX k=3 on 2-connected graphs\n| Approx-4: MIN-MAX k=3 on connected graphs with two bicomponents\n| Approx-5: MIN-MAX k=3 on connected graphs\n| Approx-6: MAX-MIN k=3 on 2-connected graphs\n| Approx-7: MAX-MIN k=3 on connected graphs with two bicomponents\n| Approx-8: MAX-MIN k=3 on connected graphs\n\nInstallation (linux commands shown)\n############\nCreate a Python3.8 virtual environment (confirm version with 'python --version')::\n    \n    python3.8 -m venv env\n\nActivate the created environment::\n    \n    source env/bin/activate\n    \nInstall the package::\n    \n    pip install git+https://github.com/curtiskennedy/graph-partition.git@2021.8.22\n\nNavigate to any folder containing instances (or containing sub-folders of instances)::\n    \n    cd instances\n\nRun the package using::\n    \n    partition\n\nDeactivate the virtual environment, the partition command will no longer work::\n    \n    deactivate\n",
    'author': 'curtiskennedy',
    'author_email': 'curtisdeankennedy@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/curtiskennedy/graph-partition',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

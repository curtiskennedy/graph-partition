graph-partition

| Approx-1: MAX-MIN k=2 on 2-connected graphs
| Approx-2: MAX-MIN k=2 on connected graphs
| Approx-3: MIN-MAX k=3 on 2-connected graphs
| Approx-4: MIN-MAX k=3 on connected graphs with two bicomponents
| Approx-5: MIN-MAX k=3 on connected graphs

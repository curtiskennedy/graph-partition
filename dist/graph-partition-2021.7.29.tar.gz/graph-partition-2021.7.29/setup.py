# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['graph_partition', 'graph_partition.algorithms', 'graph_partition.classes']

package_data = \
{'': ['*']}

install_requires = \
['PyInquirer>=1.0.3,<2.0.0', 'pyfiglet>=0.8.post1,<0.9']

entry_points = \
{'console_scripts': ['partition = graph_partition.main:cli']}

setup_kwargs = {
    'name': 'graph-partition',
    'version': '2021.7.29',
    'description': 'vertex-weighted graph partitioning',
    'long_description': 'graph-partition\n\n| Approx-1: MAX-MIN k=2 on 2-connected graphs\n| Approx-2: MAX-MIN k=2 on connected graphs\n| Approx-3: MIN-MAX k=3 on 2-connected graphs\n| Approx-4: MIN-MAX k=3 on connected graphs with two bicomponents\n| Approx-5: MIN-MAX k=3 on connected graphs\n',
    'author': 'curtiskennedy',
    'author_email': 'curtisdeankennedy@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/curtiskennedy/graph-partition',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
